# %%
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd

from scipy.signal import find_peaks
from pybaselines import Baseline
from skimage.restoration import denoise_bilateral

import os

from stark_mapper import StarkMapsGenerator
# %%
# Custom matpltotlib style 
# can be deleted with no harm 
mpl.style.use('custom-style')

path = 'G:\\My Drive\\Vaults\\WnM-AMO\\__Data\\2025-08-21\\data\\data-imgs-7-2025-06-11.npz'
sm = StarkMapsGenerator(path, bin_power=6)
sm.plot_batch_imgs(binned=True)
# %%
squid_path = 'G:\\My Drive\\Vaults\\WnM-AMO\\__Scripts\\calculated_sark_map.csv'
squid_df = pd.read_csv(squid_path, index_col=0)
squid_df
# %%
squid_df.plot(x='E')
squid_df.head()
# %%
stark_maps = sm.get_stark_maps()[:]
# %%
nspec, ny, nx = stark_maps.shape
fig, ax = plt.subplots(nrows=nspec, 
                       figsize=(3,8),
                       sharex=True)
flat_stark_maps = stark_maps.flatten()
glob_max = np.max(flat_stark_maps)
glob_min = np.min(flat_stark_maps)
time, x, y = sm.get_time_distance()
for a,s in zip(ax, stark_maps):
    a.pcolormesh(x, time, s, 
                 cmap='inferno', 
                 vmin=glob_min,
                 vmax=glob_max)
    a.axvline(x=x[480])
fig.supxlabel('Distance (mm)',
              y=0.05)
fig.supylabel('Frequency (seconds)',
              x=-0.03)

# %%
# Freq. axis calibration
bins = 2**7
s_cal = np.array([st.reshape(-1, bins).mean(axis=1) for st in stark_maps[2]])[:,0]
p1, _ = find_peaks(s_cal, width=[1, 30], prominence=0.35)
print(p1)
fig, ax = plt.subplots()
ax.plot(time, s_cal, 'o-', alpha=0.6)
ax.plot(time[p1],s_cal[p1], 'o', c='r')
ax.set_title('Axis calibration')
#%%
sec_to_mhz = -137.54814724194335 / np.abs(time[p1[0]] - time[p1[1]])
freq = sec_to_mhz * (time - time[p1[0]]) - 0
print(f'Conversion factor: {sec_to_mhz} MHz/sec')


# %%
# Matched filtering
s_tmp = stark_maps[2]
print(s_tmp.shape)
bins = 2**3
s_map = np.array([st.reshape(-1, bins).mean(axis=1) for st in s_tmp])
print(s_map.shape)
spec_idx = int(300/bins)
s = s_map[:,spec_idx]

# %%
save_dict = {
    "file_id": 'data-imgs-7-2025-08-21.npz',
    "comments": f'Vert. distance: 2',
    "map_data": s_tmp,
    "frequency_mhz": freq,
    "distance_mm": x
}
np.savez('data-smap-9-2025-08-21', **save_dict)
file = np.load('data-smap-8-2025-08-21.npz')
print(file.files)

# %%
def g(x, m, s):
    return np.exp(-0.5*((x-m)/s)**2) / (s*np.sqrt(2*np.pi))

# def model1(x, par_dict):
#     out = g(x, par_dict['D5/2 mj=5/2'])


sigma = 1
f1 = g(freq,0,sigma)
f2 = (g(freq,-15,sigma) + g(freq,10,sigma) + g(freq,60,sigma))*10
c1 = np.convolve(s,np.flip(f1),mode='same')
c2 = np.convolve(s,np.flip(f2),mode='same')

fig, ax = plt.subplots()
ax.plot(freq, s, 'o-', alpha=0.4)
ax.plot(freq, f1, 'v-', alpha=0.6)
ax.plot(freq, c1, 's-', alpha=0.6)
ax.plot(freq, f2, '^-', alpha=0.6)
ax.plot(freq, c2, 'x-', alpha=0.6)
n_freq = len(freq)
amax = c2.argmax()
ax.axvline(x=freq[amax],c='k', linestyle='--')


E = squid_df['E'].to_numpy()
Ei = np.linspace(E[0], E[-1], 800)
Dpos = np.array(
            [np.interp(Ei, E, squid_df['n=44 L=2 J=5/2 $m_j$=5/2'].to_numpy()),
            np.interp(Ei, E, squid_df['n=44 L=2 J=5/2 $m_j$=3/2'].to_numpy()),
            np.interp(Ei, E, squid_df['n=44 L=2 J=5/2 $m_j$=1/2'].to_numpy()),
            np.interp(Ei, E, squid_df['n=44 L=2 J=3/2 $m_j$=3/2'].to_numpy()),
            np.interp(Ei, E, squid_df['n=44 L=2 J=3/2 $m_j$=1/2'].to_numpy())]
        )
gradients = np.abs(np.gradient(Dpos, axis=1))

# rel_int = [3,2,2,1,1]
# SCALE = 0.1
# Dwidth = (4.3 + SCALE * (gradients - np.repeat(gradients.T[0][:,np.newaxis], 
#                              repeats=gradients.shape[1], 
#                              axis=1))) 
#--------------------
# rel_int = [3,2,2,1,1]
# SCALE_D = 0
# SCALE_P = -7e-3
# SHIFT = 3
# Dwidth = (SHIFT + 
#           SCALE_P * (Dpos - np.repeat(Dpos.T[0][:,np.newaxis], 
#                              repeats=Dpos.shape[1], 
#                              axis=1))
#           + SCALE_D * (gradients - np.repeat(gradients.T[0][:,np.newaxis], 
#                              repeats=gradients.shape[1], 
#                              axis=1))**2) 
#--------------------

# rel_int = [3,2,2,1,1]
# SCALE = 4.5
# SCALE_D = 0.3
# Dwidth =SCALE*(1+SCALE_D*(gradients - np.repeat(gradients.T[0][:,np.newaxis], 
#                              repeats=gradients.shape[1], 
#                              axis=1))**3)
#--------------------
# rel_int = [3,2,2,1,1]
# SCALE = 3.5
# SCALE_D = 0.1
# Dwidth =SCALE*(1+SCALE_D*(gradients - np.repeat(gradients.T[0][:,np.newaxis], 
#                              repeats=gradients.shape[1], 
#                              axis=1))**1.8)
#--------------------
# >>> BEST RESULT SO FAR!
# rel_int = [3,2,2,1,1]
# SCALE = 2.6
# SCALE_D = 0.1
# Dwidth =SCALE*(1+SCALE_D*(gradients - np.repeat(gradients.T[0][:,np.newaxis], 
#                              repeats=gradients.shape[1], 
#                              axis=1))**2)
#--------------------
rel_int = [3,2,2,1,1]
SCALE = 2
SCALE_D = 0.1
Dwidth =SCALE*(1+SCALE_D*(gradients - np.repeat(gradients.T[0][:,np.newaxis], 
                             repeats=gradients.shape[1], 
                             axis=1))**2)



fig, ax = plt.subplots()
for d in Dwidth:
    ax.plot(Ei,d)
ax.set_ylim([1,10])

mathced_filter_map = np.zeros((len(Ei), len(time)))

cmax = 0
cargmax = 0
Erec = 0
Eidx = 0

for i, e in enumerate(Ei):
    model = np.zeros(len(freq))
    id = 0
    for d,w,A in zip(Dpos, Dwidth, rel_int):
            model += g(freq,d[i],w[i]) * A
    model = model * s.max()/ model.max()
    c = np.convolve(s,np.flip(model),mode='same')
    c = c*c
    if cmax < c.max():
        cmax = c.max()
        cargmax = c.argmax()
        Eidx = i
        Erec = e
    mathced_filter_map[i] = c
print(f'Reconsrtucted field: {Erec}\nCmax: {cmax}')
print(Dwidth.T[Eidx])
print(Dpos.T[Eidx])


fig, ax = plt.subplots(1,2)
nx = 6
ny = 10
ax[0].pcolormesh(mathced_filter_map[Eidx-ny:Eidx+ny, cargmax-nx:cargmax+nx])
ax[1].plot(mathced_filter_map[Eidx-ny:Eidx+ny, cargmax],'o-')
ax[1].plot(mathced_filter_map[Eidx, cargmax-nx:cargmax+nx],'v-')




#fig, ax = plt.subplots()
#ax.pcolormesh(freq, Ei, mathced_filter_map, cmap='jet')
fig, ax = plt.subplots(2,1, sharex=True, dpi=300)
ax[1].plot(freq, s, 'o-', alpha=0.4, label='Data')
f_total = np.zeros(len(freq))
for i,d in enumerate(Dpos):
    print(i)
    print(Eidx)
    print(Dpos.shape)
    f = g(freq,Dpos[i, Eidx], Dwidth[i, Eidx]) * rel_int[i] *10
    f_total += f
    if i<3:
        ax[1].axvline(x=d[Eidx], c='r')
        ax[1].plot(freq, f, c='r')
    else:
        ax[1].axvline(x=d[Eidx], c='b')
        ax[1].plot(freq, f, c='b')
f_total = f_total * s.max()/f_total.max()
ax[1].plot(freq, f_total, 'v-', c='C2', alpha=0.4, label='Fit')
ax[0].pcolormesh(freq, Ei, mathced_filter_map, cmap='jet')
ax[0].axhline(y=Erec, c='white', linestyle='--')
ax[0].axvline(x=freq[cargmax], c='white', linestyle='--')
ax[1].grid(True)
ax[1].legend()
ax[1].set_xlabel('Blue detuning (MHz)')
ax[1].set_ylabel('EIT Signal (%)')
ax[0].set_ylabel('E-field V/cm')
# %%

def e_field_infer(frequency, spectrum, peaks=5):
    matched_filter_map = np.zeros((len(Ei), len(frequency)))
    convolve_max = 0
    convolve_index = 0
    e_reconstr = 0
    e_index = 0
    ff = frequency
    # ff = np.linspace(frequency[0], frequency[-1], len(frequency))
    ii = 0
    for e,d,w in zip(Ei, Dpos.T, Dwidth.T):
        model_peaks = np.zeros(len(ff))
        for i,r in enumerate(rel_int):
            print(i,r)
            model_peaks += g(ff,d[i],w[i]) * r
        model_peaks = model_peaks * spectrum.max() / model_peaks.max()
        convolve = np.convolve(spectrum,np.flip(model_peaks),mode='same')
        convolve = convolve * convolve
        print(convolve.shape)
        if convolve_max < convolve.max():
            convolve_max = convolve.max()
            convolve_index = convolve.argmax()
            e_reconstr = e
            e_index = ii
            matched_filter_map[ii] = convolve
        ii += 1
    n_e = 2
    n_f = 2
    vert_max_vicinity = matched_filter_map[e_index-n_e:e_index+n_e, convolve_index]
    hor_max_vicinity = matched_filter_map[e_index,
                                          convolve_index-n_f:convolve_index+n_f]
    e_max_vicinity = Ei[e_index-n_e:e_index+n_e]
    f_max_vicinity = ff[convolve_index-n_f:convolve_index+n_f]
    # plt.figure()
    # plt.plot(f_max_vicinity, hor_max_vicinity)
    # plt.figure()
    # plt.plot(e_max_vicinity, vert_max_vicinity)

    metric_e_quad_interp = np.polyfit(e_max_vicinity,
                                  vert_max_vicinity,
                                  deg=2)
    # metric_f_quad_interp = np.polyfit(f_max_vicinity,
    #                               hor_max_vicinity,
    #                               deg=2)
    
    e_error = 0.5/metric_e_quad_interp[0]# * metric_f_quad_interp[0]*0.5
    # print(f'Reconsrtucted field: {E_reconstr}\nCmax: {convolve_max}')
    # print(Dwidth.T[E_index])
    # print(Dpos.T[E_index])
    return e_reconstr, e_index, convolve_max, e_error


def e_field_profile(stark_map, frequency):
    print(stark_map.T.shape)
    Eprofile = np.zeros(stark_map.shape[1])
    Eerror = np.zeros(stark_map.shape[1])
    metric_max = 0
    for i,spec in enumerate(stark_map.T):
        #print(i)
        E_field, E_idx, metric_current, e_err  = e_field_infer(frequency, spec,5)
        #break
        if metric_max < metric_current:
            Eprofile[i] = E_field
            Eerror[i] = np.abs(e_err)
            # break
    return Eprofile, Eerror

# %%

plt.imshow(s_map)


#%%
E_reconstructed, Eerror = e_field_profile(s_map, freq)
print(E_reconstructed)
        



# %%




sigma_x = 5e4# 10e-6

theta = 0.0
xx = np.linspace(0,10.8, len(E_reconstructed)) / np.cos(theta)
x0 = 5.58#5.2#4.85 #mm
z0 = 0.45
probe_radius = 0.8/2 # mm
Esurface = 2.7 #2.7
Emodel0 =  Esurface * probe_radius/np.sqrt((xx - x0)**2 + z0**2)
# Emodel1 =  Esurface * probe_radius/np.sqrt((xx - 4.85)**2)
fig, ax = plt.subplots(2,1,sharex=True,dpi=300)
ax[0].pcolormesh(xx,freq,s_map,cmap='jet')
ax[0].set_ylabel('Blue Detuning (MHz)')
ax[1].plot(xx, E_reconstructed, '.', alpha=0.5, label='Experiment',c='b')
ax[1].axvspan(x0-probe_radius, x0+probe_radius, alpha=.2, color='C4')
ax[1].errorbar(x=xx, y=E_reconstructed, yerr=Eerror*sigma_x, 
               linestyle='None', 
               c='b',
               capsize=1,
               alpha=0.7)
ax[1].plot(xx, Emodel0, c='C3',linewidth=1.5,label='Model 0')
# ax[1].plot(xx, Emodel1, c='C2',linewidth=1.5,label='Model 0')
ax[1].set_ylim([0,4])
ax[1].set_ylabel('E-field (V/cm)')
ax[1].set_xlabel('Distance along laser (mm)')
ax[1].grid(True)
ax[1].legend()
ax[1].text(x=1,y=3,s='$E=E_{S}\\frac{R}{r}$')
ax[1].axvline(x=x0, c='k', linestyle='--')
ax[1].text(x=x0-0.1,y=3.5,s='L-probe position',rotation=0,ha='right')
fig.suptitle('E-field reconstruction', fontsize=16)
# %%
def remove_outliers_zscore(data, threshold=3):
    """
    Removes outliers from a time series using the Z-score method.

    Args:
        data (np.array): The time series data.
        threshold (float): The Z-score threshold for outlier detection.

    Returns:
        np.array: The data with outliers removed (or replaced).
    """
    mean = np.mean(data)
    std_dev = np.std(data)
    z_scores = np.abs((data - mean) / std_dev)
    # Option 1: Filter out outliers
    # return data[z_scores < threshold]
    # Option 2: Replace outliers with NaN or a more suitable value
    cleaned_data = np.full(len(data), True)
    cleaned_data[z_scores >= threshold] = False # Or replace with mean, median, etc.
    return cleaned_data


# %%
from lmfit import Model

def model0(x, Vs, x0, z0):
    x_cm = x*1e-1
    x0_cm = x0*1e-1
    z0_cm = z0*1e-1
    Emodel = Vs/np.sqrt((x_cm - x0_cm)**2 + z0_cm**2)
    return Emodel

def model1(x, c, Vs, x0, z0):
    Emodel = model0(x, Vs, x0, z0)
    idx_below_c = np.where(Emodel < c)
    Emodel[idx_below_c] = c
    return Emodel

model = Model(model1)

exclude_range =  ~((xx > 4.7) & (xx < 6.3))
exclude_range[-6] = False
exclude_faults = remove_outliers_zscore(E_reconstructed, threshold=50)
exclude_mask = exclude_range & exclude_faults
# print(exclude_mask)
# print(exclude_faults)

model.set_param_hint('c', vary=False)
model.set_param_hint('Vs', vary=False)
model.set_param_hint('x0', vary=False)
params = model.make_params(c=0.55508164,       # V/cm
                           Vs=0.1137411,  # V
                           x0=5.64455948,     # mm
                           z0=0.523     # mm
                           ) 



weights = 1/(Eerror*sigma_x)
result = model.fit(E_reconstructed[exclude_mask], 
                   x=xx[exclude_mask], 
                   params=params, 
                   weights=weights[exclude_mask])
print(result.fit_report())

p0, p1, p2, p3 = result.best_values.values()
y0 = model0(xx, p1, p2, p3)
y1 = model1(xx, p0, p1, p2, p3)

fig, ax = plt.subplots(2,1,sharex=True,dpi=300)
ax[0].pcolormesh(xx,freq,s_map,cmap='jet')
ax[0].set_ylabel('Blue Detuning (MHz)')
ax[1].plot(xx, E_reconstructed, '.', alpha=0.5, label='Experiment',c='b')
ax[1].plot(xx[~exclude_mask], E_reconstructed[~exclude_mask], 'x', c='r', alpha=1, label='Excluded')
ax[1].axvspan(p2-probe_radius, p2+probe_radius, alpha=.2, color='C4')
ax[1].errorbar(x=xx, y=E_reconstructed, yerr=Eerror*sigma_x, 
               linestyle='None', 
               c='b',
               capsize=1,
               alpha=0.7)
ax[1].plot(xx, y0, c='k',linewidth=1.5, linestyle='--',label='Model 0')
ax[1].plot(xx, y1, c='C3',linewidth=1.5,label='Model 1')
# ax[1].plot(xx, Emodel1, c='C2',linewidth=1.5,label='Model 0')
ax[1].set_ylim([0,4])
ax[1].set_ylabel('E-field (V/cm)')
ax[1].set_xlabel('Distance along laser (mm)')
ax[1].grid(True)
ax[1].legend()
ax[1].text(x=1,y=3,s='$E=\\frac{V_S}{r}$')
ax[1].axvline(x=p2, c='k', linestyle='--')
ax[1].text(x=p2-0.1,y=3.5,s='L-probe position',rotation=0,ha='right')
fig.suptitle('E-field reconstruction', fontsize=16)
# %%
