
# %%
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

import os

from stark_mapper import StarkMapsGenerator

# %%

# Custom matpltotlib style 
# can be deleted with no harm 
mpl.style.use('custom-style')
path = 'G:\\My Drive\\Vaults\\WnM-AMO\\__Data\\2025-08-07\\data\\data-imgs-2-2025-08-07.npz'
sm = StarkMapsGenerator(path, bin_power=5)
sm.plot_batch_imgs(binned=True)
# %%
stark_maps = sm.get_stark_maps()[4:-3]
# %%
nspec, ny, nx = stark_maps.shape
fig, ax = plt.subplots(nrows=nspec, 
                       figsize=(3,8),
                       sharex=True)
flat_stark_maps = stark_maps.flatten()
glob_max = np.max(flat_stark_maps)
glob_min = np.min(flat_stark_maps)
time, x, y = sm.get_time_distance()
for a,s in zip(ax, stark_maps):
    a.pcolormesh(x, time, s, 
                 cmap='inferno', 
                 vmin=glob_min,
                 vmax=glob_max)
fig.supxlabel('Distance (mm)',
              y=0.05)
fig.supylabel('Frequency (seconds)',
              x=-0.03)

# %%

smap = stark_maps[2]
# %%
def g(x, m, s):
    return np.exp(-0.5*((x-m)/s)**2)

def match(a, b, t, d=(0,5,100)):
    dist = np.linspace(d[0], d[1], d[2])
    print(dist)
    ref = np.zeros((d[-1], 68))
    matched = np.zeros((d[-1],68))
    ss = 0.04
    for i in range(d[-1]):
        print(dist[i])
        ref = g(time,0, ss) + g(time,dist[i], ss)
        matched[i] = np.convolve(a, np.flip(ref), mode='same')

    flat_argmax = np.argmax(matched)
    two_d_indices = np.unravel_index(flat_argmax, matched.shape)
    plt.pcolormesh(matched)
    #plt.plot(two_d_indices[0], two_d_indices[1], 'o', color='red')

# %%
tt = time
peak = g(tt, np.median(tt), 0.04) + g(tt, np.median(tt)+3.7-1.6, 0.04)
plt.plot(tt, peak, 'o-')
# %%
nn = 755
mf = np.convolve(smap[:,nn], np.flip(peak),mode='same')
plt.plot(time, smap[:,nn])
plt.plot(time, mf)
# %%
print(smap.shape)
# %%
match(smap[:,nn], [],tt)
# %%
