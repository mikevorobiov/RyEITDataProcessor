'''
Mykhailo Vorobiov

Created: 2025-08-20
Modified: 2025-08-20
'''
# %%
import numpy as np
import matplotlib.pyplot as plt
import datetime as dt
import os
import pandas as pd

from lmfit import CompositeModel # Ensure CompositeModel is imported
from lmfit.models import GaussianModel, ConstantModel


from stark_map import StarkMap
from pybaselines import Baseline
import copy
from os.path import join
from scipy.signal import find_peaks
#%%
class StarkMapCalibrator():
    '''
    Class for calibrating StarkMaps.
    '''
    def __init__(self):

        self.file_id = None
        self.map = None
        self.reference_time = None
        self.reference_signal = None

        self.reference_signal_cleaned = None
        self.calibration_dict = None

        self.frequency = None
        self.sec_to_mhz = None


        self.fps = None
        self.fov = None
        self.sweep = None

    def set_params(self, fps, fov, sweep):
        self.fps = fps
        self.fov = fov
        self.sweep = sweep
    
    def read_csv_map(self, file_id, file_path):
        self.file_id = file_path.split('\\')[-1]
        self.map = np.genfromtxt(file_path, comments='#', delimiter=',').T
        return self.map

    def read_csv_ref(self, file_path, ):
        self.reference_time, self.reference_signal = np.genfromtxt(file_path, comments='#', delimiter=',').T
        return self.reference_time, self.reference_signal
    
    def save(self, file_path):
        sm = StarkMap(self.file_id, self.map, self.calibration_dict[])
    
    def _correct_ref_baseline(self,
                              max_half_window: int = 90,
                              decreasing: bool = False,
                              smooth_half_window: int = 20
                              ) -> tuple[np.ndarray, np.ndarray]:

        # Assuming raw_reference_trace is structured as [[x1, x2, ...], [y1, y2, ...]]
        x_data = self.reference_time
        y_data = self.reference_signal

        # Initialize the Baseline fitter
        baseline_fitter = Baseline(x_data=x_data)

        # Apply the SNIP algorithm
        # The second return value (params) is discarded as it's not used
        background, _ = baseline_fitter.snip(y_data,
                                             max_half_window=max_half_window,
                                             decreasing=decreasing,
                                             smooth_half_window=smooth_half_window
                                             )

        # Correct the signal by subtracting the baseline
        y_corrected = y_data - background
        corrected_trace = np.vstack((x_data, y_corrected))
        return corrected_trace, background
    
    def _find_eit_peaks(self,
                   signal: np.ndarray,
                   number_of_peaks: int = 2,
                   min_peak_width: int = 15,
                   max_peak_width: int = 300,
                   min_peak_distance: int = 600,
                   prominence: float = 0.5,
                   filter_window_size: int = 30,  
                   return_peak_properties: bool = False
                   ) -> np.ndarray:
        """
        Identifies and selects the specified number of most prominent peaks from a signal.

        This function uses `scipy.signal.find_peaks` to locate peaks based on
        specified width and distance criteria. It then selects the 'number_of_peaks'
        strongest (highest amplitude) peaks from those found.

        Args:
            signal (np.ndarray): The 1D input signal (e.g., EIT spectrum) to find peaks in.
            number_of_peaks (int, optional): The desired number of most prominent peaks to return. Defaults to 2.
            min_peak_width (int, optional): Required width of peaks in samples. Defaults to 15.
            max_peak_width (int, optional): Maximum allowed width of peaks in samples. Defaults to 300.
            min_peak_distance (int, optional): Required minimum horizontal distance (in samples)
                                               between neighboring peaks. Defaults to 50.
            return_peak_properties (bool, optional): If True, also returns the peak properties
                                                     dictionary from `find_peaks`. Defaults to False.

        Returns:
            np.ndarray: An array of the indices of the selected peaks, sorted by position.
                        If `return_peak_properties` is True, returns a tuple:
                        (np.ndarray, dict) containing peak indices and the properties dictionary.

        Raises:
            ValueError: If fewer than 'number_of_peaks' are found based on the criteria.
        """
        

        # Find all peaks that satisfy the width and distance criteria
        peak_indices, properties = find_peaks(
            signal,
            width=[min_peak_width, max_peak_width],
            distance=min_peak_distance,
            prominence=prominence
        )

        if len(peak_indices) < number_of_peaks:
            raise ValueError(
                f"Could not locate enough peaks! Found {len(peak_indices)} peaks, "
                f"but {number_of_peaks} were requested. Adjust peak search parameters if necessary."
            )

        # Sort peaks by their amplitude in descending order
        # Get the amplitudes of the found peaks
        peak_amplitudes = signal[peak_indices]
        # Get the indices that would sort peak_amplitudes in descending order
        sorted_indices_by_amplitude = np.argsort(peak_amplitudes)[::-1]

        # Select the top 'number_of_peaks' strongest peaks
        top_peak_original_indices = peak_indices[sorted_indices_by_amplitude[:number_of_peaks]]

        # Sort the selected peaks by their original position for consistent output
        final_peak_indices = np.sort(top_peak_original_indices)

        if return_peak_properties:
            print("Note: Returning all properties from initial find_peaks call. " \
            "Consider re-evaluating if specific properties for only the selected peaks are needed.")
            return final_peak_indices, properties
        else:
            return final_peak_indices
    
    def _calibrate_axis(self,
                        separation: float,
                        number_of_peaks: int = 2,
                        min_peak_width: int = 5,
                        max_peak_width: int = 500,
                        min_peak_distance: int = 400,
                        prominence = 0.0
                        ):

        signal, background = self._correct_ref_baseline()
        x, y = signal
        try:
            peak_indices = self._find_eit_peaks(y,
                                                number_of_peaks = number_of_peaks,
                                                min_peak_width = min_peak_width,
                                                max_peak_width = max_peak_width,
                                                min_peak_distance = min_peak_distance,
                                                prominence = prominence)
        except ValueError:
            print('Error: Less than 2 peaks found. Cannot continue fitting calibration trace!')
            
            

        # Fit two-gaussians model        
        gmodel = GaussianModel(prefix='d52_') + GaussianModel(prefix='d32_')
        pars = gmodel.make_params(
            d52_center = x[peak_indices[0]],
            d52_sigma = 0.15,
            d52_amplitude = 1e-2,
            d32_center = x[peak_indices[1]],
            d32_sigma = 0.15,
            d32_amplitude = 1e-3,
        )
        pars.set(d52_sigma = {"expr": 'd32_sigma'})
        pars.set(d52_amplitude = {"min": 1e-3})
        pars.set(d32_amplitude = {"min": 1e-6})

        ref_fit_results = gmodel.fit(y,pars,x=x)

        best_pars = ref_fit_results.best_values
        main_center = best_pars['d52_center']
        subs_center = best_pars['d32_center']

        sec_to_mhz = separation / np.abs(main_center-subs_center)

        out_calibrations_dict = {"Seconds to MHz": sec_to_mhz,
                                 "Main peak (sec)": main_center,
                                 "Sub peak (sec)": subs_center,
                                 "Peaks indices": peak_indices,
                                 "lmfit result": ref_fit_results,
                                 "Background samples": background
                                 }
        half_period_sec = 0.5/ self.sweep
        self.frequency = (
                            main_center
                            - np.linspace(0, half_period_sec, self.map.shape[1])
                            ) * sec_to_mhz
        self.distance = np.linspace(0, self.fov, self.map.shape[1])
        self.calibration_dict = out_calibrations_dict
        return out_calibrations_dict

    def plot_calibration(self,
                         figsize: tuple = (4, 6),
                         height_ratios: tuple = (3, 3, 1),
                         main_title: str = "EIT Calibration Plot",
                         y_label_corrected_signal: str = 'Corr. signal (V)',
                         y_label_raw_signal: str = 'Raw signal (V)',
                         y_label_residual: str = 'Resid. (V)',
                         x_label_time: str = 'Time (sec)'
                         ) -> plt.Figure:

        # --- 1. Data Retrieval and Validation ---
        try:
            # Assuming raw_reference_trace is structured as [[x_data], [y_data]]
            x_data = self.reference_time
            y_data_raw = self.reference_signal
        except (AttributeError, TypeError) as e:
            raise AttributeError(
                f"Class attribute 'raw_reference_trace' not found or malformed: {e}. "
                "Ensure it's a 2D array (e.g., [[x_data], [y_data]]) before plotting."
            )

        try:
            bkg = self.calibration_dict["Background samples"]
            pidx = self.calibration_dict["Peaks indices"]
            fit_result = self.calibration_dict["lmfit result"]
            y_data_corrected = y_data_raw - bkg # Re-calculate for consistency or assume it's stored
            # If y_corrected is stored directly, use it:
            # y_data_corrected = self.calibrations_dict.get("Corrected signal", y_data_raw - bkg)

        except KeyError as e:
            raise KeyError(
                f"Missing required data in 'calibrations_dict': {e}. "
                "Ensure 'Background samples', 'Peaks indices', and 'lmfit result' are present."
            )
        except AttributeError as e:
            raise AttributeError(
                f"'calibrations_dict' attribute not found: {e}. "
                "Ensure the calibration process has been run successfully."
            )


        # --- 2. Figure and Axes Setup ---
        fig, ax = plt.subplots(3, 1,
                               figsize=figsize,
                               height_ratios=height_ratios,
                               sharex=True
                               )
        fig.suptitle(main_title, fontsize=14, y=1.02) # Adds a main title to the figure

        # --- 3. Plotting Subplot 1: Raw, Baseline, and Corrected Signal with Peaks ---
        ax[0].plot(x_data, y_data_corrected, 'C0', label='Corrected Signal')
        if pidx.size > 0: # Only plot peaks if any were found
            ax[0].plot(x_data[pidx], y_data_corrected[pidx], 'o', color='red', markersize=6, label='Detected Peaks')
        ax[0].set_ylabel(y_label_corrected_signal)
        ax[0].legend(loc='upper left', frameon=False) # frameon=False for cleaner look

        # Twin axis for raw signal and baseline
        ax0_twin = ax[0].twinx()
        ax0_twin.plot(x_data, y_data_raw, 'C1', label='Raw Signal')
        ax0_twin.plot(x_data, bkg, 'k', linestyle='--', label='Baseline')
        ax0_twin.set_ylabel(y_label_raw_signal)
        ax0_twin.legend(loc='upper right', frameon=False)


        # --- 4. Plotting Subplot 2: Corrected Signal with Fit ---
        ax[1].plot(x_data, y_data_corrected, 'C0', label='Corrected Signal')
        ax[1].plot(x_data, fit_result.init_fit, '--', color='orange', label='Initial Guess') # Use specific color for clarity
        ax[1].plot(x_data, fit_result.best_fit, 'r-', label='Best Fit', linewidth=1.5)
        ax[1].set_ylabel(y_label_corrected_signal)
        ax[1].legend(frameon=False)


        # --- 5. Plotting Subplot 3: Residuals ---
        ax[2].plot(x_data, fit_result.residual, 'g', label='Residuals')
        ax[2].set_ylabel(y_label_residual)
        ax[2].set_xlabel(x_label_time)
        ax[2].legend(frameon=False)
        ax[2].axhline(0, color='black', linestyle=':', linewidth=1) # Add a zero line for residuals

        # --- 6. Final Touches ---
        # Adjust layout to prevent labels from overlapping
        fig.tight_layout(rect=[0, 0.03, 1, 0.98]) # Adjust rect to make space for suptitle

        return fig, ax
    
    @classmethod
    def read_files(dirpath_str: str, 
                   key: str='spec', 
                   files_idx_ommit: list[int]=[],
                   delimiter=',',
                   comments='#',
                   fix_mismatch=True):
        if os.path.exists(dirpath_str):
            print("Provided path exists. ", dirpath_str)
            all_files_list = os.listdir(dirpath_str)
            files_list = [f for f in all_files_list if f.endswith('.csv') and os.path.isfile(os.path.join(dirpath_str, f)) and key in f]
            split_names = [f.split('-') for f in files_list]
            try:
                file_idxs = [int(f[2]) for f in split_names]
            except ValueError:
                print('Error: Cannot convert string file # to integer!')
            valid_files = [(id,f) for id,f in zip(file_idxs, files_list) if id not in files_idx_ommit]
            valid_files_sorted = sorted(valid_files)
            print()
            valid_files_paths = [join(dirpath_str, s[1]) for s in valid_files_sorted]

            data = None
            for f in valid_files_paths:
                print(f.split('\\')[-1])
                current_data = np.genfromtxt(f,delimiter=delimiter,comments=comments)
                if data is None:
                    data = current_data[np.newaxis]
                else:
                    data_dims = data.shape
                    current_data_dims = current_data.shape
                    mismatch = data_dims[1] - current_data_dims[0]
                    if fix_mismatch and mismatch>0:
                        last_row = current_data[-1][np.newaxis].T
                        print('Last arr', last_row.shape)
                        extension_arr = np.repeat(last_row, mismatch, axis=1).T
                        print('Extnshn arr', extension_arr.shape)
                        extended_arr = np.vstack((current_data, extension_arr))
                        print('Extndd arr', extended_arr.shape)
                        data = np.append(data, extended_arr[np.newaxis] , axis=0)
                    elif fix_mismatch and mismatch<0:
                        data = np.append(data, current_data[np.newaxis,:data_dims[1]] , axis=0)
                    else:
                        data = np.append(data, current_data[np.newaxis] , axis=0)
            return data, valid_files_paths
        else:
            print("Provided path does no exist! ", dirpath_str)
            return None

#%%
if __name__=='__main__':
    dirpath = 'G:\\My Drive\\Vaults\\WnM-AMO\\__Data\\2025-08-20\\raw_stark_maps'

    smc = StarkMapCalibrator()
    smc.read_csv_ref(join(dirpath, 'processed-sync-1-2025-08-20.csv'))
    smc.read_csv_map(join(dirpath, 'processed-spec-1-2025-08-20.csv'))
# %%
    #smc._correct_ref_baseline()
    smc._calibrate_axis(137.54814724194335)
# %%
    smc.plot_calibration()

# %%
